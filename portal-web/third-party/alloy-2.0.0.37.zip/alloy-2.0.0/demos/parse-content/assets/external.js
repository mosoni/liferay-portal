YUI().use('aui-node-base', function(A) {
	A.getBody().append(index++ + 'external file<br/>');
});